<?php

$function_list['client_get_all,client_get,client_add,client_update,client_delete,client_get_sites_by_user,client_get_by_username,client_get_by_customer_no,client_change_password,client_get_id,client_delete_everything,client_get_emailcontact'] = 'Client functions';
$function_list['domains_domain_get,domains_domain_add,domains_domain_update,domains_domain_delete,domains_get_all_by_user'] = 'Domaintool functions';
$function_list['quota_get_by_user,trafficquota_get_by_user,mailquota_get_by_user,databasequota_get_by_user'] = 'Quota functions';


?>
