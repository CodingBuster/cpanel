-- --------------------------------------------------------

ALTER TABLE  `web_domain` ADD  `perl` enum('n','y') NOT NULL default 'n' AFTER  `python`;

